<?php

require_once('conf.php');
include_once('bd/AcionesBD.php');


$u=new Usuario();
		/* establesco los datos al objeto pasandole el $_POST y nombre del fichero */
$u->fijarDatos($_POST,$_FILES['foto']['name']);

		/* recuperacion de los datos... */
	$nombre=$u->getNombre();
	$apellidos=$u->getApellidos();
	$fechaNacimiento=$u->getFechaNacimiento();
	$fechaNacimientoFormato=$u->getFechaNacimiento('d-m-Y');
	$ciudad=$u->getCiudad();
	$sexo=$u->getSexo();
	$aficciones=$u->getAficciones();
	$foto=$u->getFoto();
	/* guardo el fichero de la foto */
	$fichero_subido = 'descargas/'. basename($foto);

if ((($_FILES["foto"]["type"] == "image/gif")||($_FILES["foto"]["type"] == "image/jpeg")
		||($_FILES["foto"]["type"] == "image/jpg")|| ($_FILES["foto"]["type"] == "image/JPG")
		||($_FILES["foto"]["type"] == "image/pjpeg") )&&($_FILES["foto"]["size"] < 10000000)) {
		move_uploaded_file($_FILES["foto"]["tmp_name"], "descargas/" . $foto); 
	}

$sql=<<<EOT
CREATE TABLE usuarios(
idusuario INT(6) AUTO_INCREMENT PRIMARY KEY NOT NULL,
nombre VARCHAR(50) NOT NULL,
apellidos VARCHAR(50) NOT NULL,
fechaNacimiento DATE NOT NULL,
sexo VARCHAR(1) NOT NULL,
ciudad VARCHAR(50) NOT NULL,
aficciones VARCHAR(25) NOT NULL,
foto VARCHAR(255),
fechaRegistro TIMESTAMP NOT NULL
)COLLATE utf8_unicode_ci
EOT;

$o=new AccionesBD();
$o->crearTabla($sql,"EMPLEADOS");

$insReg="INSERT INTO usuarios(nombre,apellidos,fechaNacimiento,sexo,ciudad,aficciones,foto,fechaRegistro) VALUES(?,?,?,?,?,?,?,NOW())";

$datos=array($nombre,$apellidos,$fechaNacimiento,$sexo,$ciudad,$aficciones,$foto);

$o->insertarRegistro($insReg,$datos);

?>
<body>
	<header>
		<h1>Felicidades aqui esta tu contenido</h1>
	</header>
<main>
	<section>
		<h3>Tus Datos introducidos son</h3>
		<label><?=LBL_NOMBRE ?></label>
		<label><?=$nombre ?></label>
		<label><?=LBL_APELLIDOS ?></label>
		<label><?=$apellidos ?></label>
		<label><?=LBL_FECHA_NACIMIENTO ?></label>
		<label><?=$fechaNacimientoFormato ?></label>
		<label><?=LBL_CIUDAD_NACIMIENTO ?></label>
		<label><?=$ciudad ?></label>
		<label><?=LBL_SEXO ?></label>
		<label><?=$sexo ?></label>
		<label><?=LBL_AFICIONES ?></label>
		<label><?=$aficciones ?></label>
		<label><?=LBL_FOTO ?></label>
		<label><?=$foto ?></label>
	</section>
</main>
<?php include_once('pie.php'); ?>