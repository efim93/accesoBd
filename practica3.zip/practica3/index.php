<?php
require_once('conf.php');
include_once('bd/conexion.php');

$dbname="EMPLEADOS";

	$dB="CREATE DATABASE $dbname COLLATE utf8_unicode_ci";
		$conn=new Conectar();
		
	/**
	 * creo la base de datos
	 * para depurar el objeto pdo usa: var_dump($conn->__toString());
	 */
	try{
		$pdo=$conn->conexionInicial();
		$count=$pdo->exec($dB);
	}catch(Exception $e){
		echo $e->getMessage();
	}
?>
<body>
	<header>
		<h1>Bienvenido a inicio de aplicación</h1>
	</header>
<main>
	<section>
		<h2>Elige una opción</h2>
		<div class="aliniacionInicio">
			<a type="submit" href="formulario.php" name="frontend" class="butonrojo" >ir a Front-end</a>
			<a type="submit" href="admin.php" name="backend" class="butonazul">ir a Back-end</a>
		</div>
	</section>
</main>
<?php include_once('pie.php'); ?>