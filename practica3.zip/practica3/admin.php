<?php
include_once('conf.php');
include_once('bd/AcionesBD.php');

	 /* variables */
	$cosas=' ';
	$datos = array();
	$i=0;
	
$o=new AccionesBD();
$datos=$o->seleccionarDatos("SELECT idUsuario,nombre,apellidos FROM usuarios","EMPLEADOS");

	// recorro el aray de datos y estructuro los datos en una variable: cosas	
		echo "<pre>";
		foreach ($datos as $key) {
			$cosas.="<tr>";
			foreach ($key as $value) {
				var_dump($key);
				if($key!="['idUsuario']"){	
				$cosas.="<td>".$value."</td>\n";
				}
			}
			$i++;
		$cosas.="<td><a href='acciones.php?lineaS=$i'><i class='far fa-plus-square fa-2x'></i></a></td></tr>"; 
		}
?>
<body>
	<header>
		<h1>Bienvenido a Back-end</h1>
		<a href="index.php" title="index.php" ><i class="fas fa-arrow-left fa-2x"></i></a>
	</header>
<main>
	<section>
		<h3>Datos de los usuarios registrados</h3>
		<div class="centrado">
		<table>
			<thead>
			<th><?=LBL_NOMBRE ?></th>
			<th><?=LBL_APELLIDOS ?></th>
			<th></th>
			</thead>
			<tbody>
			<?=$cosas ?>
			</tbody>
		</table>
		</div>
		<div class="centrado">
			<br>
			<a href="formulario.php" id="husuario">Añadir Usuario</a>
		</div>
		</section>
</main>
<?php require_once('pie.php'); ?>