<?php 
    include_once('bd/AcionesBD.php');

    $o=new AccionesBD();
$sql="DELETE FROM usuarios WHERE idusuario = ?";

$a=array($_GET['linea']);

$result=$o->borrarRegistro($sql,"EMPLEADOS",$a);
/* despues de borrar le redireciono a la pagina principal del back-end */
  header('location:admin.php');

 ?>