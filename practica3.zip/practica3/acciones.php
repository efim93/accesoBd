<?php 

require_once('conf.php');
include_once('bd/AcionesBD.php');
		 /* variables */
		$n=$_GET['lineaS'];
		$registro;
		$e=' ';
		$t='';
$o=new AccionesBD();
$sql="SELECT * FROM usuarios WHERE idusuario=".$n;
$datos=$o->seleccionarDatos($sql,"EMPLEADOS");

/* recorido del array contenido y almaceno los casos en una variable t que contiene toda la información estructura de datos */

$s='';

foreach ($datos as $registro) {
		foreach ($registro as $campo) {
			$s.=$campo.',';
		
		}
}

		/*	
		*	guardo los valores en el array contenido hacendo un explode...
		*/
		$contenido=explode(',',$s);

/* recorido del array contenido y almaceno los casos en una variable t que contiene toda la información estructura de datos */
	 for($i=0;$i<count($contenido);$i++){
		switch ($i) {
		    case 0:
		        $t.="<tr><th>".LBL_ID_USUARIO."</th><td>".$contenido[$i]."</td></tr>\n";
		        break;
		    case 1:
		    	$t.="<tr><th>".LBL_NOMBRE."</th><td>".$contenido[$i]."</td></tr>\n";
		        break;
		    case 2:
		        $t.="<tr><th>".LBL_APELLIDOS."</th><td>".$contenido[$i]."</td></tr>\n";
		        break;
		    case 3:
		         $t.="<tr><th>".LBL_FECHA_NACIMIENTO."</th><td>".$contenido[$i]."</td></tr>\n";
		        break;
		    case 4:
		         $t.="<tr><th>".LBL_SEXO."</th><td>".$contenido[$i]."</td></tr>\n";
		        break;
		    case 5:
		        $t.="<tr><th>".LBL_CIUDAD_NACIMIENTO."</th><td>".$contenido[$i]."</td></tr>\n";
		        break;
		    case 6:
		        $t.="<tr><th>".LBL_AFICIONES."</th><td>".$contenido[$i]."</td></tr>\n";
		        break;
		    case 7:
		        $t.="<tr><th>".LBL_FOTO."</th><td>".$contenido[$i]."</td></tr>\n";
		        break;
		    case 8:
		        $t.="<tr><th>".LBL_FECHA_REGISTRO."</th><td>".$contenido[$i]."</td></tr>\n";
		        break;
			}
		}
 ?>
 <main>
	<section>
		<h3>Datos del Registro selecionado</h3>
		<?=$e;?>
		<a href="admin.php" title="admin.php"><i class="fas fa-arrow-left fa-2x"></i></a>
		<br />
		<a href="borrar.php?linea=<?=$n?>" class="centrado"><i class="far fa-trash-alt fa-3x"></i></a>
		<br />
		<table class="centrado">
			<?=$t?>
		</table>	
	</section>
</main>
<?php include_once('pie.php'); ?>